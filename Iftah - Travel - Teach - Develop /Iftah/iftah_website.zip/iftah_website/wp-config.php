<?php
# Database Configuration
define( 'DB_NAME', 'wp_iftah' );
define( 'DB_USER', 'iftah' );
define( 'DB_PASSWORD', 'rGXZRQtAztwWMinL' );
define( 'DB_HOST', '127.0.0.1:3306' );
define( 'DB_HOST_SLAVE', '127.0.0.1:3306' );
define( 'DB_CHARSET', 'utf8' );
define( 'DB_COLLATE', 'utf8_unicode_ci' );
$table_prefix = 'wp_';



# Security Salts, Keys, Etc
define( 'AUTH_KEY', 'J!(cbs1uxG8(.,.SJ|NTHSL`4gF7-k2(n0|6=:!5!Y+:%[AK:ez(g2v]$Khj-BN4' );
define( 'SECURE_AUTH_KEY', 'NqsIeuTe(,3lFH,OI0C,y]AE,x.`0![5U*iKmF*kA7n!-DtV&c+(avW5$9#%flv*' );
define( 'LOGGED_IN_KEY', '4?9h2zHHEqE*bDnl=!vZ6-hhhx-t3Vo7luT};%P:?x-{5fWh7-Xn)^$3_@<k!?k,' );
define( 'NONCE_KEY', '05!|3:Eg1|@sHG6(Cn-[s,5=t 6SKY>v.%7-8vJ_2eB/C|5#]32 pSwt}H^]Ol?;' );
define( 'AUTH_SALT', 'WS^v"?2nW"N~w?zKamCUR1sCx)B6f-|vUy/;.Ylqm7;+x$]F=AAz6.0"Sq28DtH:' );
define( 'SECURE_AUTH_SALT', 'Qc*pw|[gK,w+)?cL!s eoC~4tEFowzJ,b5<H*8?TcVKbIM6C:FNRe$S"i3!"NqcX' );
define( 'LOGGED_IN_SALT', 'Fv>xa0yoGpKP"Q%-*8YE5`rLGA>6)+@nGIsh,^)L-K`zr$q6?q*Wx=ruk?*Fsbm^' );
define( 'NONCE_SALT', 'n%x(m_(=={1zHI)PS,c2VqIDtUWP;$3OoO0CKL*b}Xf]JPU}3CSskN3SH~B!|@gp' );



# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'iftah' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'c303197054eebf38b5444340af5fcc0a92eea691' );

define( 'WPE_FOOTER_HTML', "<a href=\"http://wpengine.com/\" target=\"_blank\">WordPress Hosting Service</a>" );

define( 'WPE_CLUSTER_ID', '100975' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_LBMASTER_IP', '' );

define( 'WPE_CDN_DISABLE_ALLOWED', true );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'iftah.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-100975', );

$wpe_special_ips=array ( 0 => '104.196.235.64', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( );

define( 'WPE_SFTP_ENDPOINT', '' );
define( 'WPLANG', '' );



# WP Engine Settings





define( 'WPE_CACHE_TYPE', 'standard' );



























/*SSLSTART*/
if ( isset( $_SERVER['HTTP_X_WPE_SSL'] ) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on';
/*SSLEND*/



# Custom Settings












$_wpe_preamble_path = null;



# That's It. Pencils down
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname(__FILE__) . '/' );
}
require_once( ABSPATH . 'wp-settings.php' );














